import java.util.Scanner;

import static java.lang.System.out;

public class Saiyajin {

    public String nomeSaiyajin;
    private Double kiUsuario;
    private int nivelTransformacao;

    public Double getKiUsuario() {
        return kiUsuario;
    }

    public void setKiUsuario(Double kiUsuario) {
        this.kiUsuario = kiUsuario;
    }

    public int getNivelTransformacao() {
        return nivelTransformacao;
    }

    public void setNivelTransformacao(int nivelTransformacao) {
        this.nivelTransformacao = nivelTransformacao;
    }

    public Saiyajin(String nomeSaiyajin){
        this.nomeSaiyajin = nomeSaiyajin;
        this.kiUsuario = 3000.0;
        this.nivelTransformacao = 0;
    }
    //Aqui temos o metodo ShowOptions que recebe a opção escolhida pelo usuário
    //Essa classe irá validar o número e também chamar o metodo correspondente a escolha
    public void showOptions(int selectedOption){
        switch (selectedOption) {
            case 1:
                Training();
                break;
            case 2:
                compareChars();
                break;
            case 3:
                madeFusion();
                break;
            case 4:
                out.println("Até logo!");
                break;
            default:
                out.println("Opção inválida, tente novamente");
        }
    }

    //Esse metodo é a primeira opção, onde calcula o Ki do usuário
    public void Training(){
        Scanner scan = new Scanner(System.in);

        while(true) {
            kiUsuario = this.getKiUsuario();
            out.println("Escolha um treinamento:\n" +
                    "1- Fazer flexões\n" +
                    "2- Treinar com sr Kai-oh\n" +
                    "3- Correr no caminho da serpente\n" +
                    "4- Treinar com Whis\n" +
                    "5- Voltar ao menu inicial");
            out.format("seu ki é de: %.2f\n", kiUsuario);
            Integer optionSelected = scan.nextInt();

            switch (optionSelected) {
                case 1: this.setKiUsuario(kiUsuario+500.0); break;
                case 2: this.setKiUsuario(kiUsuario+1200.0); break;
                case 3: this.setKiUsuario(kiUsuario+1000.0); break;
                case 4: this.setKiUsuario(kiUsuario+2200.0); break;
                case 5: out.format("Você finalizou com %.2f de ki", this.getKiUsuario()); break;
                default: out.println("Opção inválida, tente novamente");
            }
            if(optionSelected.equals(5)){ break;}
        }

    }

    //O próximo metodo irá permitir o usuario comparar 2 personagens diferentes entre os disponiveis
    //Para poder comparar o Ki deles e saber quem é o mais forte
    public void compareChars(){
        Scanner sc = new Scanner(System.in);

        double kiUser = this.getKiUsuario();
        String saiyajinUser = this.nomeSaiyajin;
        double kiChar = 0.0;
        String nomeChar = "";

        out.println("Escolha um personagem para comparar com o seu personagem:\n" +
                "1 - Goku\n" +
                "2- Trunks\n" +
                "3- Android 17\n");
        Integer selectedChar1 = sc.nextInt();


            switch (selectedChar1){
                case 1: kiChar = 90000; nomeChar = "Goku";
                break;
                case 2: kiChar = 7300; nomeChar = "Trunks";
                break;
                case 3: kiChar = 8000; nomeChar = "Android 17";
                break;
                default:
                    out.println("Personagem inválido, tente novamente");
            }


           if(kiChar > kiUser){
               out.printf("O %s tem o ki de %.2f e o seu saiyajin %s tem %.2f de ki, portanto seu Saiyajin perdeu\n",
                       nomeChar, kiChar, saiyajinUser, kiUser);
           }else {
               out.printf("O %s tem o ki de %.2f e o seu saiyajin %s tem %.2f de ki, portanto seu Saiyajin venceu\n",
                       nomeChar, kiChar, saiyajinUser, kiUser);
           }
    }

    public void madeFusion(){
        Scanner sc = new Scanner(System.in);

        String saiyajinUser = this.nomeSaiyajin;
        out.println("Informe o nome do personagem para fazer a fusão");
        String nameChar = sc.nextLine();

        String nameFusion = "";

        for (int i = 0; i < (saiyajinUser.length()/2) ; i++) {
            nameFusion += saiyajinUser.charAt(i);
        }
        for (int i = 0; i < nameChar.length(); i++) {

            if(i >= (nameChar.length() / 2)) {
                nameFusion += nameChar.charAt(i);
            }
        }
        out.println(nameFusion);
    }

}
