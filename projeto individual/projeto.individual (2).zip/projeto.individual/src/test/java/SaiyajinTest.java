import java.util.Scanner;
/*
* Progama escrito e desenvolvido por @Jefferson Silva
* Este é um progama feito para o projeto individual de segundo semestre da
* @SPTECH
* Um progama simples baseado no anime 'Dragon Ball'
* Feito para fins educacionais
* Version 1.0
* */

public class SaiyajinTest {
    public static void main(String[] args) {
        //Iniciando o método main importando o Scanner
        Scanner scan = new Scanner(System.in);
        //Criando a variável de referência para usar os métodos da classe ProjectDragonBall

        System.out.println("Seja bem vindo! Antes de iniciar vamos criar teu personagem!" +
                "\n Informe o nome do seu Saiyajin");
        Saiyajin saiyajinUser = new Saiyajin(scan.nextLine());

        //Laço de repetição while que irá permitir o usuário continue usando o progama
        //Sem precisar ficar iniciando todo o momento
        while(true) {

            //Aqui apareça no console para o usuário selecionar alguma opção
            System.out.println("Escolha uma opção para prosseguir:\n" +
                    "1- Treinar\n" +
                    "2-Comparar seu ki com outro personagem\n" +
                    "3- Fazer fusão\n" +
                    "4- Encerrar progama\n" +
                    "5- Joguinho bala");


            /*
            Usei o metodo Integer para armazenar a escolha do usuário
            Pois precisarei usar um dos metodos dessa classe mais a frente
            */
            Integer selectedOption = scan.nextInt();

            //A próxima linha envia a opção selecionada ao metodo showOptions da classe projectDragonBall
            saiyajinUser.showOptions(selectedOption);

            /*
            Aqui valido se o usuario escolheu a quarta opção que encerra o progama
            Usei o metodo equals da classe Integer para validar se a variable selectedOption é 4
            */
            if(selectedOption.equals(4)){ break;}

        }
    }
}
