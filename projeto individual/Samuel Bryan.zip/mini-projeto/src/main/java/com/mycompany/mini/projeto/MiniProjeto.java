/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mini.projeto;

import java.util.Scanner;

/**
 *
 * @author s6mue
 */
public class MiniProjeto {

    public static void main(String[] args) {
        


        Integer sair = 0;
        Double ienes = 0.00;

        do {

            System.out.println("----------------------------------");
            System.out.println("|     carros japoneses (JDMs)    |");
            System.out.println("----------------------------------");
            System.out.println("| 1 - converter moeda            |");
            System.out.println("| 2 - verificar                  |");
            System.out.println("| 3 - acerte o carro             |");
            System.out.println("| 0 - sair                       |");
            System.out.println("----------------------------------");

            System.out.println("escolha uma das opções!");

            Scanner leitor = new Scanner(System.in);
            Scanner leitorr = new Scanner(System.in);
            Integer numeroPrimarioDigitado = leitor.nextInt();

            switch (numeroPrimarioDigitado) {
                case 1:

                    System.out.println("digite quantos reis você deseja converter para ienes");
                    Double valorEmReais = leitor.nextDouble();
                    ienes = valorEmReais * 25.66;
                    System.out.println(String.format("seu saldo convertido para ienes é de "+"%.2f", ienes ));

                    break;
                case 2:

                    System.out.println("estamos verificando se é possivel fazer a compra de um GTR");

                    if (ienes > 2566.000) {
                        System.out.println(String.format("seu saldo é de"+" %.2f"+" ienes, você pode comprar um GTR", ienes ));
                    } else {
                        System.out.println(String.format("seu saldo é de"+" %.2f"+" ienes, você não pode comprar um GTR", ienes ));
                    }
                    ;

                    break;
                case 3:
                    System.out.println("acerte um dos tres principais carros JDM mais populares, escreva sua resposta, caso acerte um deles voce ira ganhar 1000 ienes");
                    String nomeCarro = leitorr.nextLine();

                    if (nomeCarro.equals("gtr r34")  || nomeCarro.equals("supra mk4")  || nomeCarro.equals("rx7") ) {
                        ienes += 1000;
                        
                        System.out.println(String.format("parabens voce acertou e ganhou mais 1000 ienes, voce agora tem "+ "%.2f " + "ienes", ienes ));
                        
                    }else{
                        System.out.println("não foi dessa vez, tente novamente mais tarde.");
                    }

                    break;
                case 0:
                    System.out.println("você optou por sair, até logo!");

                    ienes = 0.00;
                    sair = 1;

                    break;
                default:

            };

        } while (sair
                != 1);

    }

}
