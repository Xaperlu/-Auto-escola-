/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sptechjv.mavenproject2;
import java.util.Scanner;

/**
 *
 * @author vitor
 */
public class ProjetoIndividualSprint {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcao;
        
        do {
            // Exibe o menu
            System.out.println("Selecione uma opção:");
            System.out.println("1 - Realizar cálculo");
            System.out.println("2 - Verificar condição par ou ímpar");
            System.out.println("3 - Calcular múltiplos de 1 até 10 de um número");
            System.out.println("4 - Encerrar programa");

            // Lê a opção selecionada pelo usuário
            opcao = scanner.nextInt();

            // Processa a opção selecionada
            switch (opcao) {
                case 1:
                    // Executa o cálculo
                    System.out.println("Digite o primeiro número:");
                    int num1 = scanner.nextInt();
                    System.out.println("Digite o segundo número:");
                    int num2 = scanner.nextInt();
                    int resultado = num1 + num2;
                    System.out.println(String.format("O resultado do cálculo é: %d", resultado));
                    break;
                case 2:
                    // Verifica a condição
                    System.out.println("Digite um número:");
                    int num = scanner.nextInt();
                    String mensagem = num % 2 == 0 ? "O número é par." : "O número é ímpar.";
                    System.out.println(String.format("%s", mensagem));
                    break;
                case 3:
                    // Calcula os múltiplos do número
                    System.out.println("Digite um número:");
                    int multiplicador = scanner.nextInt();
                    for (int i = 1; i <= 10; i++) {
                        int resultadoMultiplicacao = i * multiplicador;
                        System.out.println(String.format("%d x %d = %d", multiplicador, i, resultadoMultiplicacao));
                    }
                    break;
                case 4:
                    // Encerra o programa
                    System.out.println("Encerrando o programa...");
                    break;
                default:
                    // Exibe uma mensagem de erro e repete o loop
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        } while (opcao != 4);
        
        scanner.close();
    }
}



